import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def value = message.getProperty("p_api_url");
    def encoded = value
        .replaceAll(" ", "%20")      // Replace all spaces with one time encoded space
        .replaceAll("\\[", "%255B") // Replace all [ with 2 times encoded [
        .replaceAll("\\]", "%255D") // Replace all ] with 2 times encoded ]
    
    message.setProperty("p_api_url_original", value);
    message.setProperty("p_api_url", encoded);
    
    /*
    def properties = message.getProperties();
    value = properties.get("p_customId");
    def encoded = value.replaceAll()
    
    message.setProperty("p_customId_original", value + " modified");
    message.setProperty("p_customId", "newProperty");
    */
    
    return message;
}