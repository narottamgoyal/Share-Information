import com.sap.gateway.ip.core.customdev.util.Message
import java.util.Random

def Message processData(Message message) {
    Random random = new Random()
    int randomNumber = random.nextInt(9) + 1
    message.setProperty("randomNumber", randomNumber)
    message.setBody(randomNumber.toString())
    return message
}