import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
    // Get the body of the message (XML content)
    def body = message.getBody(String)
    
    // Parse the XML content
    def parser = new XmlParser()
    def xml = parser.parseText(body)
    
    // Create a new <rows> element with the required structure
    def newRow = new Node(null, "row")
    newRow.appendNode("name", "fake-name")
    newRow.appendNode("branch", "fake-branch")
    newRow.appendNode("mobileNo", "fake")
    
    // Append the new <rows> element to the <root>
    xml.append(newRow)
    
    // Convert the updated XML back to string manually
    def updatedXml = groovy.xml.XmlUtil.serialize(xml)
    
    // Set the updated XML back in the message body
    message.setBody(updatedXml)
    
    return message
}
