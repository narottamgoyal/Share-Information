import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser

def Message processData(Message message) {
    def body = message.getBody(String)

    def parser = new XmlParser()
    def xml = parser.parseText(body)

    def mobileNo = xml.mobileNo.text()
    
    if (mobileNo.length() != 10) {
        throw new Exception("Invalid mobile number: Length of mobile number must be 10 digits.")
    }

    return message
}
