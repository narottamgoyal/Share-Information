import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    // Stream the message body to JsonSlurper (safer for large payloads)
    def reader = message.getBody(java.io.Reader)
    def json = new JsonSlurper().parse(reader)

    def p_take = (message.getProperty("p_take") ?: 2).toInteger()

    // Get current properties or set default, convert to integer
    def p_skip = (message.getProperty("p_skip") ?: 0).toInteger()

    // Check JSON array length
    def length = (json instanceof List) ? json.size() : 0

    // Increment p_skip
    p_skip += length
    message.setProperty("p_skip", p_skip)

    // If JSON array is empty, set p_run_loop2 to false
    if(length < p_take) {
        message.setProperty("p_run_loop2", false)
    }

    return message
}
