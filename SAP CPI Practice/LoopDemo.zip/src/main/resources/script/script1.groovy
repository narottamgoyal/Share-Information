import com.sap.gateway.ip.core.customdev.util.Message

Message processData(Message message) {
    Integer counter = message.getProperty("p_indx")
    message.setProperty("p_indx", counter + 1)
    return message
}
