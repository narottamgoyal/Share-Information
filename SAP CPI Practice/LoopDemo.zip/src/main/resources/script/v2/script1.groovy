// This Groovy Flowstep Version 2, running with Groovy 4, Downgrade the script if older behaviour needed.
import com.sap.it.script.v2.api.Message

Message processData(Message message) {

    def counterStr = message.getProperty("p_indx") 
    Integer counter = counterStr.toInteger()          // convert to Integer

    counter = counter + 1

    message.setProperty("p_indx", counter.toString()) // store back as String
    return message
}
