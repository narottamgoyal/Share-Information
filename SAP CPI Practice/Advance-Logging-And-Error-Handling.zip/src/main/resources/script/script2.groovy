import groovy.json.JsonBuilder;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def map = message.getProperties();
    def ex = map.get("CamelExceptionCaught");

    if (ex != null) {
        def messageLog = messageLogFactory.getMessageLog(message);

        // Log exception details
        if (messageLog != null) {
            messageLog.addAttachmentAsString("Exception Class", ex.getClass().getCanonicalName(), "text/plain");
            messageLog.addAttachmentAsString("Exception Message", ex.getMessage(), "text/plain");
            messageLog.addAttachmentAsString("Exception Stack Trace", ex.getStackTrace().toString(), "text/plain");
        }

        // Store exception details in message properties
        message.setProperty("ExceptionClass", ex.getClass().getCanonicalName());
        message.setProperty("ExceptionMessage", ex.getMessage());
        message.setProperty("ExceptionStackTrace", ex.getStackTrace().toString());

        // Handle specific exception types
        if (ex instanceof org.apache.camel.component.ahc.AhcOperationFailedException) {
            def ahcEx = ex as org.apache.camel.component.ahc.AhcOperationFailedException;
            
            if (messageLog != null) {
                messageLog.addAttachmentAsString("http.ResponseBody", ahcEx.getResponseBody(), "text/plain");
            }
            
            message.setProperty("http.ResponseBody", ahcEx.getResponseBody());
            message.setProperty("http.StatusCode", ahcEx.getStatusCode());
            message.setProperty("http.StatusText", ahcEx.getStatusText());
        }
        
        message.setProperty("p_is_error_log", "false");
        message.setBody(buildJsonString([
            "messageID": message.getProperty("p_cpi_message_Id"),
            "type": "Error",
            "processName": message.getProperty("p_process_name"),
            "errorMessage": ex.getMessage()
        ]));
    }

    return message;
}

def buildJsonString(def jsonMap) {
    def jsonBuilder = new JsonBuilder(jsonMap);
    return jsonBuilder.toPrettyString();
}
