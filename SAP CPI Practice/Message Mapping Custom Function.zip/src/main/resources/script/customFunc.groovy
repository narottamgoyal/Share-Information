import com.sap.it.api.mapping.*

def void getCorrectPhoneNumber(String[] phoneNumbers, String[] types, Output output, MappingContext context) {
    def mobilePhone = ""
    def officePhone = ""

    if (phoneNumbers == null || types == null || phoneNumbers.length != types.length) {
        output.addValue("")
        return
    }

    for (int i = 0; i < types.length; i++) {
        if ("mobile".equalsIgnoreCase(types[i])) {
            mobilePhone = phoneNumbers[i]
        } else if ("office".equalsIgnoreCase(types[i])) {
            officePhone = phoneNumbers[i]
        }
    }

    if (mobilePhone && mobilePhone != "") {
        output.addValue(mobilePhone)
    } else if (officePhone) {
        output.addValue(officePhone)
    } else {
        output.addValue("Not Available")
    }
}